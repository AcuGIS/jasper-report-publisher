#load library
library(dplyr)
library(plotly)
library(htmlwidgets)

#load data
df <- read.csv("graph.csv")

#create map
p <- plot_geo(df, locationmode = 'world') %>%
	add_trace( z = ~df$new_cases_per_million, locations = df$code, frame=~df$start_of_week, color = ~df$new_cases_per_million)

#export as html file
htmlwidgets::saveWidget(p, file = "index.html")