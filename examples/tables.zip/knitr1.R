library(insight)
library(kableExtra)

df <- data.frame(
  Variable = c(1, 3, 5, 3, 1),
  Group = c("A", "A", "A", "B", "B"),
  CI = c(0.95, 0.95, 0.95, 0.95, 0.95),
  CI_low = c(3.35, 2.425, 6.213, 12.1, 1.23),
  CI_high = c(4.23, 5.31, 7.123, 13.5, 3.61),
  p = c(0.001, 0.0456, 0.45, 0.0042, 0.34)
)

knitr::kable(df, format = "html") %>%
	kable_styling(bootstrap_options = c("striped", "hover")) %>%
	save_kable(file = "knitr1.html", self_contained = T)