library(kableExtra)
dt <- mtcars[1:5, 1:6]
dt %>%
  kbl(caption = "Recreating booktabs style table") %>%
  kable_classic(full_width = F, html_font = "Cambria") %>%
	save_kable(file = "cambria.html", self_contained = T)